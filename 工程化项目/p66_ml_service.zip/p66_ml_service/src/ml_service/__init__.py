# -*- coding: utf-8 -*-
"""模型训练与服务 —— 工程化实现包。

分层：config（配置）/ core（纯逻辑）/ io_utils（IO）/ report（报告）/ pipeline（编排）。
"""
__version__ = "1.0.0"
__all__ = ["config", "core", "io_utils", "report", "pipeline"]
